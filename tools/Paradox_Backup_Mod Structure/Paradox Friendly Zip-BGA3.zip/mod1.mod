version="10.22.26-BGA3"
tags={
	"1.20 'Crozier'"
}
name="Skonester Cheat Menu Gold"
supported_version="1.20.*"
path="mod/mod1"
remote_file_id="3398662167"
